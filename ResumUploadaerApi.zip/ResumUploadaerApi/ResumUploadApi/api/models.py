from django.db import models

# Create your models here.
STATE_CHOICE=(
    ("kpk","kpk"),
    ("punjab","punjab"),
    ("sindh","sindh"),
    ("balochistan","balochistan")
)

class Profile(models.Model):
    name=models.CharField(max_length=40)
    email=models.EmailField()
    dob=models.DateField(auto_now=False,auto_now_add=False)
    state=models.CharField(choices=STATE_CHOICE,max_length=50)
    gender=models.CharField(max_length=20)
    location=models.CharField(max_length=40)
    pimage=models.ImageField(upload_to="image",blank=True)
    rdoc=models.FileField(upload_to="rdoc",blank=True)
