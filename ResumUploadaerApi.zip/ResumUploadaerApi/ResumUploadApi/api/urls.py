from django.urls import path
from . import views

urlpatterns = [
    path("resum/",views.ProfileView.as_view(),name="Resum"),
    path("list/",views.ProfileView.as_view(),name="list"),
    
]
