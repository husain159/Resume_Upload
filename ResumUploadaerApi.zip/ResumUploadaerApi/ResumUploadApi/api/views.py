from django.shortcuts import render

# Create your views here.
from rest_framework.response import Response
from rest_framework import status
from .models import Profile
from .serializers import ProfileSerializer
from rest_framework.views import APIView

class ProfileView(APIView):
    def post(self,request,formate=None):
        serializer=ProfileSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"msg":"Resum Uplader data save","status":"success",
            "candidate":serializer.data},status=status.HTTP_201_CREATED)
            #error occure then run the below code
        return Response(serializer.errors)
    
    #data for only read
    def get(self,request,formate=None):
        candidate=Profile.objects.all()
        serializer=ProfileSerializer(candidate,many=True)
        return Response({"status":"success","candidate":serializer.data},
        status=status.HTTP_200_OK)